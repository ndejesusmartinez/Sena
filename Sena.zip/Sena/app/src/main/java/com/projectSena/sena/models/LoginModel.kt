package com.projectSena.sena.models

class LoginModel {
    var status: String=""
    var message: String=""
    var accessToken: String=""
}