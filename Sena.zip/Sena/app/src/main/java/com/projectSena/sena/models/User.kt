package com.projectSena.sena.models

class User {
    var status: String=""
    var message: String=""
    var accessToken: String=""
    var user: User = User()
}